var _=Object.defineProperty;var F=(p,g,b)=>g in p?_(p,g,{enumerable:!0,configurable:!0,writable:!0,value:b}):p[g]=b;var o=(p,g,b)=>F(p,typeof g!="symbol"?g+"":g,b);(function(){"use strict";const p={fontFamily:"opendyslexic",fontSize:18,lineHeight:1.6,letterSpacing:1,wordSpacing:2,focusMode:!1,focusUnit:"sentence",readingSpeed:1,simplificationEnabled:!1,backendApiUrl:"http://localhost:3000/api/simplify"},g=[{id:"original",label:"Original",fontFamily:"inherit"},{id:"opendyslexic",label:"OpenDyslexic",fontFamily:"OpenDyslexic, sans-serif"},{id:"lexend",label:"Lexend",fontFamily:"Lexend, sans-serif"}];async function b(){return new Promise(s=>{if(typeof chrome<"u"&&chrome.storage&&chrome.storage.sync)chrome.storage.sync.get("dyslexia_reader_settings",e=>{chrome.runtime.lastError||!e.dyslexia_reader_settings?s({...p}):s({...p,...e.dyslexia_reader_settings})});else{try{const e=localStorage.getItem("dyslexia_reader_settings");if(e){s({...p,...JSON.parse(e)});return}}catch{}s({...p})}})}const C="dyslexia-reader-styles";function I(){let s=document.getElementById(C);s||(s=document.createElement("style"),s.id=C,(document.head||document.documentElement).appendChild(s));const e=typeof chrome<"u"&&chrome.runtime&&chrome.runtime.getURL?chrome.runtime.getURL(""):"";s.textContent=`
    /* Font definitions */
    @font-face {
      font-family: 'OpenDyslexic';
      src: url('${e}fonts/OpenDyslexic/OpenDyslexic-Regular.otf') format('opentype'),
           url('${e}fonts/OpenDyslexic/OpenDyslexic-Regular.woff2') format('woff2');
      font-weight: normal;
      font-style: normal;
      font-display: swap;
    }

    @font-face {
      font-family: 'Lexend';
      src: url('${e}fonts/Lexend/Lexend-Regular.ttf') format('truetype'),
           url('${e}fonts/Lexend/Lexend-Regular.woff2') format('woff2');
      font-weight: normal;
      font-style: normal;
      font-display: swap;
    }

    /* Core typography layer applied directly to content elements when enabled */
    :root {
      --dr-font-family: inherit;
      --dr-font-size: 18px;
      --dr-line-height: 1.6;
      --dr-letter-spacing: 1px;
      --dr-word-spacing: 2px;
    }

    /* Target readable text content elements and nested spans/links directly on any webpage */
    html.dyslexia-reader-enabled p,
    html.dyslexia-reader-enabled p *,
    html.dyslexia-reader-enabled h1,
    html.dyslexia-reader-enabled h1 *,
    html.dyslexia-reader-enabled h2,
    html.dyslexia-reader-enabled h2 *,
    html.dyslexia-reader-enabled h3,
    html.dyslexia-reader-enabled h3 *,
    html.dyslexia-reader-enabled h4,
    html.dyslexia-reader-enabled h4 *,
    html.dyslexia-reader-enabled h5,
    html.dyslexia-reader-enabled h5 *,
    html.dyslexia-reader-enabled h6,
    html.dyslexia-reader-enabled h6 *,
    html.dyslexia-reader-enabled li,
    html.dyslexia-reader-enabled li *,
    html.dyslexia-reader-enabled dt,
    html.dyslexia-reader-enabled dd,
    html.dyslexia-reader-enabled blockquote,
    html.dyslexia-reader-enabled blockquote *,
    html.dyslexia-reader-enabled article p,
    html.dyslexia-reader-enabled article span,
    html.dyslexia-reader-enabled .entry-content p,
    html.dyslexia-reader-enabled .entry-content span,
    html.dyslexia-reader-enabled .post-content p,
    html.dyslexia-reader-enabled .post-content span,
    html.dyslexia-reader-enabled .dr-readable-text {
      font-family: var(--dr-font-family) !important;
      font-size: var(--dr-font-size) !important;
      line-height: var(--dr-line-height) !important;
      letter-spacing: var(--dr-letter-spacing) !important;
      word-spacing: var(--dr-word-spacing) !important;
    }

    /* Preserve interactive buttons, inputs, icons, and code blocks */
    html.dyslexia-reader-enabled code,
    html.dyslexia-reader-enabled pre,
    html.dyslexia-reader-enabled button,
    html.dyslexia-reader-enabled input,
    html.dyslexia-reader-enabled textarea,
    html.dyslexia-reader-enabled select,
    html.dyslexia-reader-enabled svg,
    html.dyslexia-reader-enabled svg * {
      font-size: initial;
      line-height: initial;
      letter-spacing: initial;
      word-spacing: initial;
    }

    /* Focus Mode Highlight Style: Clear, distinct, accessible pastel yellow with soft border */
    mark.dr-focus-highlight {
      background-color: #fff3a3 !important;
      color: #1a1a1a !important;
      border-radius: 4px !important;
      padding: 2px 4px !important;
      box-shadow: 0 0 0 2px #f59e0b !important;
      display: inline !important;
      transition: background-color 0.15s ease, box-shadow 0.15s ease !important;
    }

    /* High contrast mode for active focus element container */
    .dr-focus-active-container {
      outline: 2px dashed #2563eb !important;
      outline-offset: 4px !important;
      border-radius: 4px !important;
    }

    /* Simplified selection highlight badge */
    mark.dr-simplified-selection {
      background-color: #e0f2fe !important;
      color: #0369a1 !important;
      border: 1px solid #0284c7 !important;
      border-radius: 4px !important;
      padding: 2px 6px !important;
      font-weight: 500 !important;
      display: inline !important;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1) !important;
    }
  `}function U(){const s=document.getElementById(C);s&&s.parentNode&&s.parentNode.removeChild(s)}const v=new Set(["SCRIPT","STYLE","SVG","CANVAS","INPUT","TEXTAREA","SELECT","BUTTON","CODE","PRE","NOSCRIPT","IFRAME","OBJECT","EMBED"]);class T{getReadableElements(e=document.body){if(!e)return[];const t=[],i=document.createTreeWalker(e,NodeFilter.SHOW_ELEMENT,{acceptNode:r=>{const a=r;return this.isExcludedElement(a)?NodeFilter.FILTER_REJECT:this.isReadableElement(a)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}});let n=i.nextNode();for(;n;)t.push(n),n=i.nextNode();return t}extractPageText(){var r;const e=this.getReadableElements(),t=[],i=[];for(const a of e){const u=a.innerText?a.innerText.trim():((r=a.textContent)==null?void 0:r.trim())||"";u.length>0&&(t.push({element:a,text:u,tag:a.tagName.toLowerCase()}),i.push(u))}return{fullText:i.join(`

`),blocks:t}}chunkText(e,t=3e3){if(!e||e.length<=t)return e?[e]:[];const i=e.split(`

`),n=[];let r="";for(const a of i)if((r+`

`+a).length>t)if(r.trim().length>0&&n.push(r.trim()),a.length>t){const u=a.match(/[^.!?]+[.!?]+(\s|$)/g)||[a];let d="";for(const l of u)(d+l).length>t?(d.trim().length>0&&n.push(d.trim()),d=l):d+=l;d.trim().length>0?r=d:r=""}else r=a;else r=r?r+`

`+a:a;return r.trim().length>0&&n.push(r.trim()),n}isExcludedElement(e){if(!e||!e.tagName)return!0;const t=e.tagName.toUpperCase();if(v.has(t)||e.isContentEditable||e.getAttribute("aria-hidden")==="true"||e.classList.contains("dr-ignore")||e.closest("nav, header, footer, .menu, .nav, .site-header, .header-wrap"))return!0;if(typeof window<"u"){const i=window.getComputedStyle(e);if(i.display==="none"||i.visibility==="hidden"||i.opacity==="0")return!0}return!1}isReadableElement(e){var n;const t=e.tagName.toUpperCase();return new Set(["P","H1","H2","H3","H4","H5","H6","LI","DT","DD","BLOCKQUOTE","ARTICLE","SECTION"]).has(t)?(e.innerText?e.innerText.trim():((n=e.textContent)==null?void 0:n.trim())||"").length>2:!1}}class R{constructor(){o(this,"textExtractor");o(this,"isEnabled",!1);this.textExtractor=new T}applySettings(e){I();const t=document.documentElement;t.classList.add("dyslexia-reader-enabled");const i=g.find(r=>r.id===e.fontFamily),n=i?i.fontFamily:"inherit";t.style.setProperty("--dr-font-family",n),t.style.setProperty("--dr-font-size",`${e.fontSize}px`),t.style.setProperty("--dr-line-height",`${e.lineHeight}`),t.style.setProperty("--dr-letter-spacing",`${e.letterSpacing}px`),t.style.setProperty("--dr-word-spacing",`${e.wordSpacing}px`),this.markReadableElements(),this.isEnabled=!0}markReadableElements(){const e=this.textExtractor.getReadableElements();for(const t of e)t.classList.contains("dr-readable-text")||t.classList.add("dr-readable-text")}reset(){const e=document.documentElement;e.classList.remove("dyslexia-reader-enabled"),e.style.removeProperty("--dr-font-family"),e.style.removeProperty("--dr-font-size"),e.style.removeProperty("--dr-line-height"),e.style.removeProperty("--dr-letter-spacing"),e.style.removeProperty("--dr-word-spacing"),document.querySelectorAll(".dr-readable-text").forEach(i=>i.classList.remove("dr-readable-text")),U(),this.isEnabled=!1}getIsActive(){return this.isEnabled}}class M{constructor(){o(this,"textExtractor");o(this,"readingUnits",[]);o(this,"currentIndex",-1);o(this,"isActive",!1);o(this,"currentUnitType","sentence");o(this,"currentHighlightMark",null);o(this,"observer",null);o(this,"processedNodes",new WeakSet);o(this,"clickListener",null);o(this,"onUnitClickedCallback");this.textExtractor=new T}setOnUnitClicked(e){this.onUnitClickedCallback=e}enable(e="sentence"){this.currentUnitType=e,this.isActive=!0,this.buildReadingSequence(e),this.setupMutationObserver(),this.setupClickListener();const t=window.getSelection();t&&t.toString().trim()?this.setStartingFromSelection(t.toString().trim()):this.readingUnits.length>0&&this.currentIndex===-1&&this.highlightIndex(0)}disable(){this.removeCurrentHighlight(),this.removeClickListener(),this.readingUnits=[],this.currentIndex=-1,this.isActive=!1,this.observer&&(this.observer.disconnect(),this.observer=null)}setFocusUnit(e){const t=this.isActive;this.disable(),t&&this.enable(e)}buildReadingSequence(e){const t=this.textExtractor.getReadableElements(),i=[];for(const n of t){const r=this.getTextNodes(n);for(const a of r){const u=a.nodeValue||"";if(u.trim()){if(e==="paragraph")i.push({text:u.trim(),element:n,textNode:a,startOffset:0,endOffset:u.length,unitType:e});else if(e==="sentence"){const d=/[^.!?]+[.!?]+(?:\s|$)|[^.!?]+$/g;let l;for(;(l=d.exec(u))!==null;){const c=l[0].trim();c.length>0&&i.push({text:c,element:n,textNode:a,startOffset:l.index,endOffset:l.index+l[0].length,unitType:e})}}else if(e==="word"){const d=/\b[\w'-]+\b/g;let l;for(;(l=d.exec(u))!==null;){const c=l[0];c.length>0&&i.push({text:c,element:n,textNode:a,startOffset:l.index,endOffset:l.index+l[0].length,unitType:e})}}}}}return this.readingUnits=i,i}setStartingFromElement(e){this.readingUnits.length===0&&this.buildReadingSequence(this.currentUnitType);const t=this.readingUnits.findIndex(i=>i.element===e||i.element.contains(e)||e.contains(i.element));return t!==-1?(this.highlightIndex(t),t):-1}setStartingFromSelection(e){if(!e)return-1;const t=e.toLowerCase().trim(),i=this.readingUnits.findIndex(n=>n.text.toLowerCase().includes(t)||t.includes(n.text.toLowerCase()));return i!==-1?(this.highlightIndex(i),i):-1}highlightIndex(e){if(e<0||e>=this.readingUnits.length)return null;this.removeCurrentHighlight(),this.currentIndex=e;const t=this.readingUnits[e];try{const i=document.createRange();i.setStart(t.textNode,Math.min(t.startOffset,t.textNode.length)),i.setEnd(t.textNode,Math.min(t.endOffset,t.textNode.length));const n=document.createElement("mark");n.className="dr-focus-highlight",i.surroundContents(n),this.currentHighlightMark=n,n.scrollIntoView({behavior:"smooth",block:"nearest"})}catch(i){console.warn("[DyslexiaReader] Focus highlight range error:",i),t.element.classList.add("dr-focus-active-container"),t.element.scrollIntoView({behavior:"smooth",block:"nearest"})}return t}nextUnit(){return this.currentIndex<this.readingUnits.length-1?this.highlightIndex(this.currentIndex+1):null}previousUnit(){return this.currentIndex>0?this.highlightIndex(this.currentIndex-1):null}getCurrentUnit(){return this.currentIndex>=0&&this.currentIndex<this.readingUnits.length?this.readingUnits[this.currentIndex]:null}getCurrentIndex(){return this.currentIndex}getTotalUnits(){return this.readingUnits.length}getIsActive(){return this.isActive}removeCurrentHighlight(){if(this.currentHighlightMark&&this.currentHighlightMark.parentNode){const e=this.currentHighlightMark.parentNode;for(;this.currentHighlightMark.firstChild;)e.insertBefore(this.currentHighlightMark.firstChild,this.currentHighlightMark);e.removeChild(this.currentHighlightMark),e.normalize(),this.currentHighlightMark=null}document.querySelectorAll(".dr-focus-active-container").forEach(e=>{e.classList.remove("dr-focus-active-container")})}getTextNodes(e){const t=[],i=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode:r=>!r.nodeValue||!r.nodeValue.trim()||r.parentElement&&this.textExtractor.isExcludedElement(r.parentElement)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});let n=i.nextNode();for(;n;)t.push(n),n=i.nextNode();return t}setupClickListener(){this.clickListener||(this.clickListener=e=>{if(!this.isActive)return;const t=e.target;if(!t||this.textExtractor.isExcludedElement(t))return;const i=this.setStartingFromElement(t);if(i!==-1&&this.onUnitClickedCallback){const n=this.readingUnits[i];this.onUnitClickedCallback(n,i)}},document.addEventListener("click",this.clickListener,!0))}removeClickListener(){this.clickListener&&(document.removeEventListener("click",this.clickListener,!0),this.clickListener=null)}setupMutationObserver(){this.observer||(this.observer=new MutationObserver(e=>{let t=!1;for(const i of e)if(i.addedNodes.length>0)for(const n of Array.from(i.addedNodes))n.nodeType===Node.ELEMENT_NODE&&!this.processedNodes.has(n)&&(this.processedNodes.add(n),t=!0);if(t&&this.isActive){const i=this.currentIndex;this.buildReadingSequence(this.currentUnitType),i>=0&&i<this.readingUnits.length&&(this.currentIndex=i)}}),this.observer.observe(document.body,{childList:!0,subtree:!0}))}}class N{constructor(e){o(this,"synth",null);o(this,"currentUtterance",null);o(this,"focusManager");o(this,"readingSpeed",1);o(this,"isSpeaking",!1);o(this,"isPaused",!1);o(this,"onStateChangeCallback");this.focusManager=e,typeof window<"u"&&"speechSynthesis"in window?this.synth=window.speechSynthesis:console.warn("[DyslexiaReader] Web Speech API is not supported in this browser environment."),this.focusManager.setOnUnitClicked(()=>{(this.isSpeaking||this.isPaused)&&this.speakCurrentUnit()})}isAvailable(){return this.synth!==null}setOnStateChange(e){this.onStateChangeCallback=e}setSpeed(e){this.readingSpeed=e,this.isSpeaking&&this.currentUtterance&&this.synth&&this.focusManager.getCurrentUnit()&&this.speakCurrentUnit()}startReading(){if(!this.isAvailable())return;if(this.isPaused&&this.synth){this.synth.resume(),this.isPaused=!1,this.isSpeaking=!0,this.notifyStateChange();return}this.focusManager.getIsActive()||this.focusManager.enable("sentence");const e=window.getSelection();e&&e.toString().trim()?this.focusManager.setStartingFromSelection(e.toString().trim()):this.focusManager.getCurrentIndex()<0&&this.focusManager.highlightIndex(0),this.speakCurrentUnit()}pauseReading(){!this.isAvailable()||!this.synth||this.isSpeaking&&(this.synth.pause(),this.isPaused=!0,this.isSpeaking=!1,this.notifyStateChange())}stopReading(){this.synth&&this.synth.cancel(),this.isSpeaking=!1,this.isPaused=!1,this.currentUtterance=null,this.notifyStateChange()}nextUnit(){this.stopSynthOnly(),this.focusManager.nextUnit()&&(this.isSpeaking||this.isPaused)?this.speakCurrentUnit():this.notifyStateChange()}previousUnit(){this.stopSynthOnly(),this.focusManager.previousUnit()&&(this.isSpeaking||this.isPaused)?this.speakCurrentUnit():this.notifyStateChange()}speakCurrentUnit(){if(!this.synth)return;const e=this.focusManager.getCurrentUnit();if(!e){this.stopReading();return}this.stopSynthOnly();const t=new SpeechSynthesisUtterance(e.text);t.rate=this.readingSpeed,t.onstart=()=>{this.isSpeaking=!0,this.isPaused=!1,this.notifyStateChange()},t.onend=()=>{this.isSpeaking&&(this.focusManager.nextUnit()?this.speakCurrentUnit():this.stopReading())},t.onerror=i=>{console.error("[DyslexiaReader] Speech synthesis utterance error:",i),this.stopReading()},this.currentUtterance=t,this.synth.speak(t)}stopSynthOnly(){this.synth&&this.synth.cancel()}notifyStateChange(){this.onStateChangeCallback&&this.onStateChangeCallback({isReading:this.isSpeaking,isPaused:this.isPaused,currentIndex:this.focusManager.getCurrentIndex()})}}class L{constructor(){o(this,"textExtractor");o(this,"originalContentMap",new Map);o(this,"simplifiedContentMap",new Map);o(this,"currentViewMode","original");o(this,"status","idle");o(this,"lastError",null);this.textExtractor=new T}getStatus(){return this.status}getLastError(){return this.lastError}getCurrentViewMode(){return this.currentViewMode}hasSimplifiedText(){return this.simplifiedContentMap.size>0}async simplifyPage(e="http://localhost:3000/api/simplify"){this.status="extracting",this.lastError=null;const t=this.textExtractor.getReadableElements();if(t.length===0)return this.status="error",this.lastError="No readable text content found on this page.",!1;for(const r of t)this.originalContentMap.has(r)||this.originalContentMap.set(r,r.innerHTML);const{fullText:i}=this.textExtractor.extractPageText(),n=this.textExtractor.chunkText(i,3e3);this.status="simplifying";try{const r=n.map(async(c,y)=>{const w=await fetch(e,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:c,chunkIndex:y,totalChunks:n.length})});if(!w.ok){const P=await w.json().catch(()=>({}));throw new Error(P.error||`Server responded with status ${w.status}`)}const k=await w.json();if(!k.simplifiedText)throw new Error("Backend returned empty simplified response.");return{index:y,text:this.cleanAiOutput(k.simplifiedText)}}),a=await Promise.all(r);a.sort((c,y)=>c.index-y.index);const d=a.map(c=>c.text).join(`

`).split(/\n\n+/);let l=0;for(const c of t)if(l<d.length){const y=d[l].trim();y&&this.simplifiedContentMap.set(c,y),l++}return this.status="success",this.showSimplified(),!0}catch(r){return console.error("[DyslexiaReader] Simplification error:",r),this.status="error",this.lastError=r.message||"Failed to simplify page text. Make sure backend server is running.",!1}}async simplifySelectedText(e,t="http://localhost:3000/api/simplify"){var n;const i=e||((n=window.getSelection())==null?void 0:n.toString().trim());if(!i||i.length<3)return this.simplifyPage(t);this.status="simplifying",this.lastError=null;try{const r=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:i})});if(!r.ok){const l=await r.json().catch(()=>({}));throw new Error(l.error||`Server responded with status ${r.status}`)}const a=await r.json();if(!a.simplifiedText)throw new Error("Backend returned empty simplified response.");const u=this.cleanAiOutput(a.simplifiedText),d=window.getSelection();if(d&&d.rangeCount>0&&d.toString().trim()){const l=d.getRangeAt(0),c=document.createElement("mark");c.className="dr-simplified-selection",c.title="✨ Simplified with Dyslexia Reader",c.innerText=u,l.deleteContents(),l.insertNode(c),d.removeAllRanges()}return this.status="success",!0}catch(r){return console.error("[DyslexiaReader] Selection simplify error:",r),this.status="error",this.lastError=r.message||"Failed to simplify selected text.",!1}}cleanAiOutput(e){return e?e.replace(/^#+\s+/gm,"").replace(/^---+$/gm,"").replace(/^(Here is|Here's|For easier reading:?|Simplified version:?).*?\n+/i,"").replace(/^\*\s+/gm,"").trim():""}showSimplified(){if(this.simplifiedContentMap.size!==0){for(const[e,t]of this.simplifiedContentMap.entries())e.innerText=t,e.classList.add("dr-simplified-content");this.currentViewMode="simplified"}}restoreOriginal(){if(this.originalContentMap.size!==0){for(const[e,t]of this.originalContentMap.entries())e.innerHTML=t,e.classList.remove("dr-simplified-content");document.querySelectorAll(".dr-simplified-selection").forEach(e=>{const t=e.parentNode;if(t){for(;e.firstChild;)t.insertBefore(e.firstChild,e);t.removeChild(e),t.normalize()}}),this.currentViewMode="original"}}reset(){this.restoreOriginal(),this.originalContentMap.clear(),this.simplifiedContentMap.clear(),this.currentViewMode="original",this.status="idle",this.lastError=null}}console.log("[DyslexiaReader] Content script initialized on:",window.location.href);const S=new R,E=new M,m=new N(E),x=new L;let f=null;O();async function O(){f=await b(),f&&S.applySettings(f)}function h(){return{isEnabled:S.getIsActive(),focusModeActive:E.getIsActive(),currentReadingIndex:E.getCurrentIndex(),totalReadingUnits:E.getTotalUnits(),isReading:!1,isPaused:!1,hasSimplifiedText:x.hasSimplifiedText(),currentViewMode:x.getCurrentViewMode(),simplifyStatus:x.getStatus(),simplifyError:x.getLastError(),isRestrictedPage:!1,pageTitle:document.title||"Webpage"}}typeof chrome<"u"&&chrome.runtime&&chrome.runtime.onMessage&&chrome.runtime.onMessage.addListener((s,e,t)=>(A(s).then(i=>{t(i)}),!0));async function A(s){var e,t,i,n,r,a;switch(s.type){case"GET_PAGE_STATE":return h();case"APPLY_SETTINGS":return s.payload&&(f=s.payload,S.applySettings(s.payload),m.setSpeed(s.payload.readingSpeed)),h();case"ENABLE_FOCUS_MODE":const u=((e=s.payload)==null?void 0:e.focusUnit)||(f==null?void 0:f.focusUnit)||"sentence";return E.enable(u),h();case"DISABLE_FOCUS_MODE":return m.stopReading(),E.disable(),h();case"SET_FOCUS_UNIT":return(t=s.payload)!=null&&t.focusUnit&&E.setFocusUnit(s.payload.focusUnit),h();case"START_READING":return m.startReading(),h();case"PAUSE_READING":return m.pauseReading(),h();case"STOP_READING":return m.stopReading(),h();case"NEXT_READING_UNIT":return m.nextUnit(),h();case"PREVIOUS_READING_UNIT":return m.previousUnit(),h();case"SET_READING_SPEED":return(i=s.payload)!=null&&i.speed&&m.setSpeed(s.payload.speed),h();case"SIMPLIFY_TEXT":const d=((n=s.payload)==null?void 0:n.backendApiUrl)||(f==null?void 0:f.backendApiUrl),l=await x.simplifyPage(d);return{...h(),success:l};case"SIMPLIFY_SELECTION":const c=((r=s.payload)==null?void 0:r.backendApiUrl)||(f==null?void 0:f.backendApiUrl),y=await x.simplifySelectedText((a=s.payload)==null?void 0:a.selectedText,c);return{...h(),success:y};case"SHOW_SIMPLIFIED":return x.showSimplified(),h();case"RESTORE_ORIGINAL":return x.restoreOriginal(),h();case"RESET_PAGE":return m.stopReading(),E.disable(),x.reset(),S.reset(),h();default:return h()}}})();
